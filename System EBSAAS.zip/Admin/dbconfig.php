<?php
$host = 'localhost';
$username = 'root';
$password = 'usbw';
$database = 'quizzer';
$dbconfig = mysqli_connect($host,$username,$password,$database);
?>
